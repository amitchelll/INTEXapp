#!/usr/bin/env bash
sudo certbot -n -d provocitymentalhealth.is404.net --nginx --agree-tos --email pickettelise0@gmail.com